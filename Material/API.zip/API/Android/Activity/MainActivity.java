package com.loginius.billing.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loginius.billing.Model.Login.Login;
import com.loginius.billing.R;
import com.loginius.billing.Remote.ApiClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    EditText unm, pwd;
    Button btnLg;
    ProgressDialog progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        unm = findViewById(R.id.username);
        pwd = findViewById(R.id.password);
        btnLg = findViewById(R.id.login);
        SharedPreferences preferences = getSharedPreferences("SonaPartners", MODE_PRIVATE);
        String check = preferences.getString("username", "");
        if (!check.isEmpty()) {
            finish();
            startActivity(new Intent(MainActivity.this, MainMenuActivity.class));
        }

        btnLg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar = new ProgressDialog(MainActivity.this);
                progressBar.setCancelable(false);
                progressBar.setMessage("Please Wait...");
                progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressBar.show();
                String user, password;
                user = unm.getText().toString();
                password = pwd.getText().toString();
                if (user.isEmpty() || password.isEmpty()) {
                    progressBar.dismiss();
                    if (user.isEmpty()) {
                        unm.setError("Please Enter  Username");
                    } else {
                        pwd.setError("Please Enter Password");
                    }
                } else {

                    Call<Login> call = ApiClient.getSona().getLogin(new Login(user, password));
                    call.enqueue(new Callback<Login>() {
                        @Override
                        public void onResponse(Call<Login> call, Response<Login> response) {
                            progressBar.dismiss();
                            if (!response.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                            }
                            if(response.body().getStatus()==null)
                            {
                                Toast.makeText(MainActivity.this, "Data Invalid", Toast.LENGTH_SHORT).show();
                            }
                            else if (response.body().getStatus().equals("1")) {
                                SharedPreferences preferences = getSharedPreferences("SonaPartners", MODE_PRIVATE);
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString("username", user);
                                editor.apply();
                                finish();
                                startActivity(new Intent(MainActivity.this, MainMenuActivity.class));
                            } else {
                                Toast.makeText(MainActivity.this, "Wrong", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Login> call, Throwable t) {

                        }
                    });
                }
            }
        });
    }
}