package com.loginius.billing.Model.Login;

public class Login {
    String unm,pwd;
    String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Login(String unm, String pwd) {
        this.unm = unm;
        this.pwd = pwd;
    }
}