package com.loginius.billing.Remote;



import com.loginius.billing.Model.Login.Login;
import com.loginius.billing.Model.Party.Party;
import com.loginius.billing.Model.Product.Product;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface Sona {

    @POST("login.php")
    Call<Login> getLogin(@Body Login login);

    @POST("addParty.php")
    Call<Party> addParty(@Body Party party);

    @POST("addProduct.php")
    Call<Product> addPrd(@Body Product  product);
}