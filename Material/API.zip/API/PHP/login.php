<?php
	
	include_once('../include/connection.php');
	header("Content-type: application/json");

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		$getData = json_decode(file_get_contents('php://input'), true);
		
		$unm=$getData["unm"];
		$pwd=$getData["pwd"];
		
		$query="select * from bill_user where username='$unm' and password='$pwd'";
		$res=mysqli_query($connection,$query);
		if($res)
		{
		    $rows=mysqli_fetch_assoc($res);
		    $data['status']=$rows['status'];
		    echo json_encode($data);
		}
		else
		{
		    $data['status']=0;
		    echo json_encode($data);
		}
	}
?>